'use strict';
/**
 * O'yinchi profili (almaz, sotib olingan qurollar) - JSON faylda saqlanadi.
 * Papka: DATA_DIR muhit o'zgaruvchisi yoki ./data
 * Eslatma: ba'zi bepul hostinglarda fayl tizimi doimiy emas - u yerda "persistent disk" ulang.
 */
const fs = require('fs');
const path = require('path');

const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const FILE = path.join(DIR, 'players.json');
let db = { players: {} };
let timer = null;

try {
  fs.mkdirSync(DIR, { recursive: true });
  if (fs.existsSync(FILE)) db = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  if (!db.players) db.players = {};
} catch (e) {
  console.error("players.json o'qilmadi, yangisi boshlanadi:", e.message);
  db = { players: {} };
}

function flush() {
  clearTimeout(timer); timer = null;
  try {
    const tmp = FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, FILE);
  } catch (e) { console.error('Saqlashda xato:', e.message); }
}
function save() {
  if (timer) return;
  timer = setTimeout(flush, 1000);
}

function get(pid, name) {
  let p = db.players[pid];
  if (!p) {
    p = db.players[pid] = { name: '', diamonds: 0, owned: ['pistol'], equipped: 'pistol', upgrades: {}, games: 0, bestWave: 0, kills: 0 };
    save();
  }
  if (!p.upgrades) p.upgrades = {};
  if (name && name !== p.name) { p.name = name; save(); }
  return p;
}
function view(p) {
  return { name: p.name, diamonds: p.diamonds, owned: p.owned, equipped: p.equipped, upgrades: p.upgrades || {}, games: p.games, bestWave: p.bestWave, kills: p.kills };
}

process.on('SIGINT', () => { flush(); process.exit(0); });
process.on('SIGTERM', () => { flush(); process.exit(0); });

module.exports = { get, view, save, flush };
