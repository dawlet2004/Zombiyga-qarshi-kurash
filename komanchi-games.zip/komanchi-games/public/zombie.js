(() => {
'use strict';

/* ================= Umumiy ================= */
const $ = id => document.getElementById(id);
const SPAWN = { left: { x: -3, z: 0 }, right: { x: 3, z: 0 }, back: { x: 0, z: -4 } };
const COLORS = { left: 0xd94040, right: 0x3d7fe0, back: 0x3dbf6a };
const SIDES = ['left', 'right', 'back'];
const MAX_LEVEL = 60;
const BULLET_Y = 1.95;

let pid = null;
try { pid = localStorage.getItem('kd_pid'); } catch (e) {}
if (!pid) {
  pid = (window.crypto && window.crypto.randomUUID) ? window.crypto.randomUUID() : (String(Math.random()).slice(2) + Date.now());
  try { localStorage.setItem('kd_pid', pid); } catch (e) {}
}
const socket = io('/zombie', { auth: { pid } });

let profile = { diamonds: 0, owned: ['pistol'], equipped: 'pistol' };
let weapons = [], byId = {};
let upCfg = { max: 5, dmgPer: 0.25, cdPer: 0.06 };
const lvlOf = id => (profile.upgrades && profile.upgrades[id]) || 0;
let mySide = null, roomCode = null, roomState = 'none', isHost = false;
let phase = 'lobby';             // lobby | countdown | playing | over
let lastRoom = null, lastResult = null, countdownTimer = null, bannerToken = 0;
let shopOpen = false, curLevel = 0, levelKey = '';
let shopR = null, shopSel = null;
const touchMode = window.matchMedia('(pointer:coarse)').matches;

/* ================= 3D sahna ================= */
const canvas = $('scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x1b2038, 70, 190);
const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 800);
const camDir = new THREE.Vector3(0, 0.66, 0.75).normalize();
const camTarget = new THREE.Vector3(0, 0.6, 1);
let camDist = 32, tanHalfH = 0.7, shake = 0;

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  const hf = 2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2) * camera.aspect);
  tanHalfH = Math.tan(hf / 2);
  $('rotateHint').hidden = !(h > w && roomCode);
  if (shopR) resizeShop();
}
window.addEventListener('resize', resize);

(function sky() {
  const c = document.createElement('canvas'); c.width = 2; c.height = 256;
  const g = c.getContext('2d'), grad = g.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, '#05081a'); grad.addColorStop(0.55, '#16253f'); grad.addColorStop(0.85, '#2a4a46'); grad.addColorStop(1, '#4a6a52');
  g.fillStyle = grad; g.fillRect(0, 0, 2, 256);
  scene.background = new THREE.CanvasTexture(c);
})();

scene.add(new THREE.HemisphereLight(0x7f95c8, 0x1a2418, 0.7));
const moon = new THREE.DirectionalLight(0xa9bfff, 0.85);
moon.position.set(-14, 26, 14);
moon.castShadow = true;
moon.shadow.mapSize.set(1024, 1024);
Object.assign(moon.shadow.camera, { left: -38, right: 38, top: 28, bottom: -28, near: 1, far: 90 });
scene.add(moon);
scene.add(moon.target);

const lam = c => new THREE.MeshLambertMaterial({ color: c });
const boxGeo = new THREE.BoxGeometry(1, 1, 1);
function box(w, h, d, color, x, y, z, parent = scene, shadow = false) {
  const m = new THREE.Mesh(boxGeo, lam(color));
  m.scale.set(w, h, d); m.position.set(x, y, z); m.castShadow = shadow; m.receiveShadow = true;
  parent.add(m); return m;
}

/* ===== Dinamik xarita: har levelda kattalashadi ===== */
const arena = { ax: 20, az: 13, tx: 20, tz: 13 };

const ground = new THREE.Mesh(new THREE.PlaneGeometry(520, 380), lam(0x1d2c22));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

const tileTex = (() => {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = '#4a4f4a'; g.fillRect(0, 0, 64, 64);
  g.fillStyle = 'rgba(255,255,255,.035)'; g.fillRect(6, 6, 24, 24);
  g.strokeStyle = '#363a36'; g.lineWidth = 3; g.strokeRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
})();
const floor = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshLambertMaterial({ map: tileTex }));
floor.rotation.x = -Math.PI / 2; floor.position.y = 0.02; floor.receiveShadow = true; scene.add(floor);

// boshlanish belgilari (3 ta o'yinchi)
for (const s of SIDES) {
  const ring = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.4, 32), new THREE.MeshBasicMaterial({ color: COLORS[s] }));
  ring.rotation.x = -Math.PI / 2; ring.position.set(SPAWN[s].x, 0.05, SPAWN[s].z); scene.add(ring);
}

// panjara ustunlari (xarita o'lchamiga qarab joylashadi)
const fence = { top: [], bottom: [], left: [], right: [] };
const postMat = lam(0x2a2e36);
function ensurePosts(pool, n) {
  while (pool.length < n) {
    const m = new THREE.Mesh(boxGeo, postMat); m.scale.set(0.25, 1.4, 0.25); m.position.y = 0.7; scene.add(m); pool.push(m);
  }
  pool.forEach((m, i) => { m.visible = i < n; });
}
function layoutFence(ax, az) {
  const X = ax + 1.6, Z = az + 1.6, nx = Math.ceil(2 * X / 4) + 1, nz = Math.ceil(2 * Z / 4) + 1;
  ensurePosts(fence.top, nx); ensurePosts(fence.bottom, nx); ensurePosts(fence.left, nz); ensurePosts(fence.right, nz);
  for (let i = 0; i < nx; i++) {
    const x = -X + 2 * X * i / (nx - 1);
    fence.top[i].position.set(x, 0.7, -Z); fence.bottom[i].position.set(x, 0.7, Z);
  }
  for (let i = 0; i < nz; i++) {
    const z = -Z + 2 * Z * i / (nz - 1);
    fence.left[i].position.set(-X, 0.7, z); fence.right[i].position.set(X, 0.7, z);
  }
}

// 3 ta kirish darvozasi: chap, o'ng, orqa
function makeGate(side) {
  const g = new THREE.Group();
  box(0.5, 4, 0.5, 0x2a2e36, 0, 2, -2.6, g, true);
  box(0.5, 4, 0.5, 0x2a2e36, 0, 2, 2.6, g, true);
  box(0.6, 0.45, 6.2, 0x2a2e36, 0, 4.1, 0, g, true);
  box(0.14, 0.9, 4.6, COLORS[side], 0, 3.3, 0, g);
  scene.add(g); return g;
}
const gates = { left: makeGate('left'), right: makeGate('right'), back: makeGate('back') };
gates.back.rotation.y = Math.PI / 2;

// qabr toshlari va daraxtlar (xarita kattalashganda ichkarida qolganlari yashiriladi)
const decor = [];
function tomb(x, z, s, ry) {
  const g = new THREE.Group(), m = lam(0x7d8590);
  const b = new THREE.Mesh(boxGeo, m); b.scale.set(1.2, 1.6, 0.4); b.position.y = 0.8; g.add(b);
  const t = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.4, 12, 1, false, 0, Math.PI), m);
  t.rotation.z = Math.PI / 2; t.rotation.y = Math.PI / 2; t.position.y = 1.6; g.add(t);
  g.position.set(x, 0, z); g.rotation.y = ry; g.scale.setScalar(s); scene.add(g);
  decor.push({ o: g, x, z });
}
function tree(x, z, s) {
  const g = new THREE.Group(), m = lam(0x2b2018);
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.4, 5, 7), m); trunk.position.y = 2.5; g.add(trunk);
  [[0.9, 4.2, 0.6], [-0.9, 3.6, -0.5], [0.4, 5.2, -0.7]].forEach(([bx, by, bz]) => {
    const br = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.16, 2.2, 6), m);
    br.position.set(bx, by, bz); br.rotation.z = -bx * 0.8; g.add(br);
  });
  g.position.set(x, 0, z); g.scale.setScalar(s); scene.add(g);
  decor.push({ o: g, x, z });
}
let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
for (let i = 0; i < 80; i++) tomb((rnd() - 0.5) * 200, (rnd() - 0.5) * 140, 0.8 + rnd() * 0.8, (rnd() - 0.5) * 0.6);
for (let i = 0; i < 16; i++) tree((rnd() - 0.5) * 200, (rnd() - 0.5) * 140, 1 + rnd() * 0.6);

// burchak fonuslari
const lamps = [];
for (let i = 0; i < 4; i++) {
  const post = box(0.3, 4, 0.3, 0x2a2e36, 0, 2, 0, scene, true);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.35, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffb870 }));
  scene.add(bulb);
  const L = new THREE.PointLight(0xff9c50, 0.9, 30); scene.add(L);
  lamps.push({ post, bulb, L });
}
const moonDisc = new THREE.Mesh(new THREE.CircleGeometry(7, 40), new THREE.MeshBasicMaterial({ color: 0xe6edff, fog: false }));
moonDisc.position.set(-32, 38, -300); moonDisc.scale.setScalar(2.4); scene.add(moonDisc);
const fogBank = new THREE.Mesh(new THREE.PlaneGeometry(500, 18), new THREE.MeshBasicMaterial({ color: 0x6a8a7a, transparent: true, opacity: 0.18, depthWrite: false }));
scene.add(fogBank);

function layoutArena(ax, az) {
  const w = 2 * ax + 3, h = 2 * az + 3;
  floor.scale.set(w, h, 1);
  tileTex.repeat.set(w / 5, h / 5);
  layoutFence(ax, az);
  gates.left.position.set(-(ax + 2.4), 0, 0);
  gates.right.position.set(ax + 2.4, 0, 0);
  gates.back.position.set(0, 0, -(az + 2.4));
  for (const d of decor) d.o.visible = Math.abs(d.x) > ax + 6 || Math.abs(d.z) > az + 6;
  const cs = [[-1, -1], [1, -1], [-1, 1], [1, 1]];
  lamps.forEach((l, i) => {
    const x = cs[i][0] * (ax + 4), z = cs[i][1] * (az + 4);
    l.post.position.set(x, 2, z); l.bulb.position.set(x, 4.3, z); l.L.position.set(x, 4.3, z);
  });
  fogBank.position.set(0, 4, -(az + 28));
}
layoutArena(arena.ax, arena.az);

/* ================= Qurol modellari ================= */
const gmCache = {};
const gm = c => gmCache[c] || (gmCache[c] = new THREE.MeshLambertMaterial({ color: c }));
function weaponModel(id) {
  const g = new THREE.Group();
  const B = (w, h, d, c, x, y, z) => { const m = new THREE.Mesh(boxGeo, gm(c)); m.scale.set(w, h, d); m.position.set(x, y, z); g.add(m); };
  const C = (r, l, c, x, y, z) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, l, 10), gm(c));
    m.rotation.x = Math.PI / 2; m.position.set(x, y, z); g.add(m);
  };
  let len = 0.8;
  switch (id) {
    case 'revolver': B(.1, .12, .75, 0xbfc3cc, 0, 0, .3); C(.14, .2, 0x9a9ea8, 0, 0, .05); B(.11, .26, .14, 0x5a3a22, 0, -.2, 0); len = .72; break;
    case 'smg': B(.14, .2, .7, 0x2f4a4a, 0, 0, .3); B(.1, .34, .12, 0x1c1c20, 0, -.24, .25); B(.1, .1, .25, 0x1c1c20, 0, 0, .78); len = .95; break;
    case 'shotgun': B(.16, .14, .9, 0x7a5232, 0, -.04, .05); C(.05, 1.2, 0x333338, -.05, .06, .55); C(.05, 1.2, 0x333338, .05, .06, .55); len = 1.15; break;
    case 'rifle': B(.14, .18, 1.0, 0x4a5a3a, 0, 0, .35); B(.1, .3, .12, 0x222222, 0, -.22, .3); B(.12, .2, .35, 0x3a2a1a, 0, -.02, -.35); C(.04, .5, 0x222222, 0, .03, 1.0); len = 1.25; break;
    case 'sniper': B(.12, .16, .9, 0x23232a, 0, 0, .2); C(.04, 1.1, 0x111111, 0, .02, 1.1); C(.09, .5, 0x2a4a8a, 0, .18, .3); B(.12, .2, .4, 0x1a1a20, 0, -.02, -.45); len = 1.65; break;
    case 'flame': B(.14, .2, .5, 0x8a3a1a, 0, 0, .2); C(.17, .55, 0xcc3322, 0, .28, -.1); C(.06, .7, 0x444444, 0, 0, .65); len = 1.0; break;
    case 'rocket': C(.2, 1.3, 0x5a6a4a, 0, .1, .3); C(.24, .12, 0x3a3a3a, 0, .1, .95); B(.06, .14, .2, 0x222222, 0, .3, .2); B(.1, .25, .12, 0x222222, 0, -.2, .1); len = 1.0; break;
    case 'minigun': C(.06, 1.0, 0x888c96, 0, .1, .6); C(.06, 1.0, 0x888c96, -.09, -.04, .6); C(.06, 1.0, 0x888c96, .09, -.04, .6);
      C(.2, .3, 0x555555, 0, 0, .1); B(.2, .25, .4, 0x3a3a42, 0, -.1, -.1); len = 1.1; break;
    case 'crossbow': B(.1, .14, .7, 0x6a4a2a, 0, 0, .2); B(.95, .08, .1, 0x3a3a40, 0, .04, .6); B(.04, .04, .8, 0xcccccc, 0, .08, .45); B(.1, .24, .12, 0x222222, 0, -.18, .05); len = .95; break;
    case 'grenade': C(.17, .8, 0x4a5a3a, 0, .1, .3); C(.27, .3, 0x2a2a2a, 0, .1, .78); B(.1, .25, .12, 0x222222, 0, -.2, .1); len = .95; break;
    case 'laser': B(.14, .18, .9, 0xe8eaf0, 0, 0, .3); C(.05, .6, 0x44e0ff, 0, .04, .95); B(.1, .12, .3, 0x2a6a8a, 0, .14, .2); B(.1, .28, .12, 0x222222, 0, -.2, .2); len = 1.25; break;
    case 'plasma': C(.2, .7, 0x3a8a5a, 0, .05, .3); C(.3, .2, 0x57ff9a, 0, .05, .72); B(.1, .26, .12, 0x222222, 0, -.2, .1); len = .9; break;
    case 'railgun': B(.16, .2, 1.2, 0x2a2a3a, 0, 0, .4); B(.06, .06, 1.4, 0x9fe8ff, .1, .05, .7); B(.06, .06, 1.4, 0x9fe8ff, -.1, .05, .7); B(.12, .26, .12, 0x222222, 0, -.2, .1); len = 1.7; break;
    default: B(.12, .18, .5, 0x2c2c34, 0, 0, .2); B(.11, .26, .14, 0x5a3a22, 0, -.2, .02); len = .5;
  }
  g.userData.len = len;
  return g;
}

/* ================= Jangchi (o'yinchi) modeli ================= */
function makeFighter(side) {
  const mats = [];
  const mat = c => { const m = new THREE.MeshLambertMaterial({ color: c, emissive: 0x000000 }); mats.push(m); return m; };
  const holder = new THREE.Group(), rig = new THREE.Group();
  holder.add(rig);
  const skin = mat(0xf1c7a0), shirt = mat(COLORS[side]), pants = mat(0x3a2d3f), hatM = mat(0x2a2a32), dark = mat(0x1d1420), team = mat(COLORS[side]);
  const add = (parent, geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = true; parent.add(o); return o; };

  const legL = new THREE.Group(); legL.position.set(-0.25, 1.0, 0); rig.add(legL);
  const legR = new THREE.Group(); legR.position.set(0.25, 1.0, 0); rig.add(legR);
  add(legL, new THREE.BoxGeometry(0.38, 1.0, 0.42), pants, 0, -0.5, 0);
  add(legR, new THREE.BoxGeometry(0.38, 1.0, 0.42), pants, 0, -0.5, 0);
  add(legL, new THREE.BoxGeometry(0.4, 0.16, 0.55), dark, 0, -0.95, 0.06);
  add(legR, new THREE.BoxGeometry(0.4, 0.16, 0.55), dark, 0, -0.95, 0.06);
  add(rig, new THREE.BoxGeometry(0.95, 1.05, 0.55), shirt, 0, 1.55, 0);
  add(rig, new THREE.BoxGeometry(1.0, 0.14, 0.6), dark, 0, 1.08, 0);
  add(rig, new THREE.SphereGeometry(0.32, 16, 12), skin, 0, 2.28, 0);
  add(rig, new THREE.BoxGeometry(0.06, 0.06, 0.05), dark, -0.11, 2.34, 0.29);
  add(rig, new THREE.BoxGeometry(0.06, 0.06, 0.05), dark, 0.11, 2.34, 0.29);
  add(rig, new THREE.BoxGeometry(0.62, 0.24, 0.1), team, 0, 2.12, 0.26);
  add(rig, new THREE.CylinderGeometry(0.4, 0.4, 0.06, 18), hatM, 0, 2.52, 0);       // dubulg'a/kepka
  add(rig, new THREE.CylinderGeometry(0.34, 0.37, 0.28, 16), hatM, 0, 2.68, 0);
  add(rig, new THREE.CylinderGeometry(0.375, 0.375, 0.07, 16), team, 0, 2.58, 0);

  const armL = new THREE.Group(); armL.position.set(-0.6, 1.95, 0); rig.add(armL);
  const armR = new THREE.Group(); armR.position.set(0.6, 1.95, 0); rig.add(armR);
  add(armL, new THREE.BoxGeometry(0.26, 0.8, 0.26), shirt, 0, -0.4, 0);
  add(armR, new THREE.BoxGeometry(0.26, 0.8, 0.26), shirt, 0, -0.4, 0);
  add(armL, new THREE.BoxGeometry(0.22, 0.2, 0.22), skin, 0, -0.9, 0);
  add(armR, new THREE.BoxGeometry(0.22, 0.2, 0.22), skin, 0, -0.9, 0);
  const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffe08a }));
  muzzle.visible = false; armR.add(muzzle);

  scene.add(holder);
  const f = {
    side, holder, rig, legL, legR, armL, armR, muzzle, mats, gun: null, weaponId: null,
    present: false, alive: true, hp: 100, name: '',
    x: SPAWN[side].x, z: SPAWN[side].z, tx: SPAWN[side].x, tz: SPAWN[side].z, aim: side === 'left' ? 0 : side === 'right' ? Math.PI : Math.PI / 2, yaw: 0, snap: false,
    mv: 0, kick: 0, flash: 0, fall: 0, seed: Math.random() * 10
  };
  setWeapon(f, 'pistol');
  return f;
}
function setWeapon(f, id, lvl) {
  lvl = lvl || 0;
  if (!id || (f.weaponId === id && f.weaponLvl === lvl)) return;
  f.weaponId = id; f.weaponLvl = lvl;
  if (f.gun) f.armR.remove(f.gun);
  const m = weaponModel(id), wrap = new THREE.Group(), S = 1.7 * (1 + 0.09 * lvl);   // qo'ldagi qurol katta; kuchaytirilgani yana kattaroq
  wrap.rotation.x = Math.PI / 2; wrap.position.set(0, -0.85, 0); wrap.scale.setScalar(S); wrap.add(m);
  f.armR.add(wrap); f.gun = wrap;
  f.muzzle.position.set(0, -0.85 - (m.userData.len || 1) * S, 0);
}
const fighters = { left: makeFighter('left'), right: makeFighter('right'), back: makeFighter('back') };

function angleLerp(a, b, k) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2;
  return a + d * k;
}

function updateFighter(f, dt, t) {
  f.holder.visible = f.present;
  if (!f.present) return;
  const px = f.x, pz = f.z, k = 1 - Math.exp(-dt * 18);
  f.x += (f.tx - f.x) * k; f.z += (f.tz - f.z) * k;
  const speed = Math.hypot(f.x - px, f.z - pz) / Math.max(dt, 0.001);
  f.mv += (Math.min(speed / 5, 1) - f.mv) * Math.min(1, dt * 12);
  f.holder.position.set(f.x, 0, f.z);

  const aim = (f.side === mySide && myAim !== null) ? myAim : f.aim;
  if (f.alive) f.yaw = angleLerp(f.yaw, Math.PI / 2 - aim, Math.min(1, dt * 14));
  f.holder.rotation.y = f.yaw;

  const sw = Math.sin(t * 11 + f.seed) * 0.75 * f.mv;
  f.legL.rotation.x = sw; f.legR.rotation.x = -sw;
  f.rig.position.y = Math.abs(Math.sin(t * 11 + f.seed)) * 0.09 * f.mv;
  f.kick = Math.max(0, f.kick - dt * 8);
  f.armR.rotation.x = -1.57 + f.kick * 0.7;
  f.armL.rotation.x = -1.25 - Math.sin(t * 11 + f.seed) * 0.1 * f.mv;
  f.muzzle.visible = f.kick > 0.75;
  f.rig.position.z = -f.kick * 0.1;

  if (!f.alive) {
    f.fall = Math.min(1, f.fall + dt * 2.2);
    const e = 1 - Math.pow(1 - f.fall, 3);
    f.rig.rotation.x = -Math.PI / 2 * e; f.rig.position.y = 0.28 * e;
    f.armR.rotation.x = 0.4 * e; f.armL.rotation.x = -0.3 * e; f.legL.rotation.x = f.legR.rotation.x = 0;
  } else { f.fall = 0; f.rig.rotation.x = 0; }

  f.flash = Math.max(0, f.flash - dt);
  const em = f.flash > 0 ? 0x992211 : 0;
  for (const m of f.mats) m.emissive.setHex(em);
}

/* ================= Zombilar ================= */
const flashMat = new THREE.MeshBasicMaterial({ color: 0xff7060 });
const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffee55 });
const bossEyeMat = new THREE.MeshBasicMaterial({ color: 0xff2200 });
const blobGeo = new THREE.CircleGeometry(0.8, 14);
const ZV = [
  { skin: lam(0x6fa35a), shirt: lam(0x5a4a6a), pants: lam(0x2f3a4a), s: [1, 1, 1], bar: 0 },
  { skin: lam(0x9ac05a), shirt: lam(0x8a3a3a), pants: lam(0x3a3a2a), s: [0.88, 0.95, 0.88], bar: 0 },
  { skin: lam(0x4f7a4a), shirt: lam(0x2a2a35), pants: lam(0x1f1f28), s: [1.5, 1.45, 1.5], bar: 4.7 },
  { skin: lam(0x8a4a5a), shirt: lam(0x1a1a1a), pants: lam(0x12121a), s: [2.4, 2.4, 2.4], bar: 7.4 }
];
const barBgMat = new THREE.MeshBasicMaterial({ color: 0x1a1020 });
const barFgMat = new THREE.MeshBasicMaterial({ color: 0x6fe36f });

function createZombie(ti) {
  const v = ZV[ti] || ZV[0];
  const holder = new THREE.Group(), rig = new THREE.Group();
  rig.scale.set(v.s[0], v.s[1], v.s[2]); holder.add(rig);
  const parts = [];
  const P = (par, w, h, d, m, x, y, z) => {
    const o = new THREE.Mesh(boxGeo, m); o.scale.set(w, h, d); o.position.set(x, y, z);
    o.userData.orig = m; par.add(o); parts.push(o); return o;
  };
  const legL = new THREE.Group(); legL.position.set(-0.22, 0.9, 0); rig.add(legL);
  const legR = new THREE.Group(); legR.position.set(0.22, 0.9, 0); rig.add(legR);
  P(legL, 0.36, 0.9, 0.4, v.pants, 0, -0.45, 0); P(legR, 0.36, 0.9, 0.4, v.pants, 0, -0.45, 0);
  P(rig, 0.9, 1.0, 0.5, v.shirt, 0, 1.4, 0);
  P(rig, 0.55, 0.55, 0.55, v.skin, 0, 2.1, 0);
  const em = ti === 3 ? bossEyeMat : eyeMat;
  const e1 = new THREE.Mesh(boxGeo, em); e1.scale.set(0.1, 0.08, 0.05); e1.position.set(-0.13, 2.14, 0.28); rig.add(e1);
  const e2 = new THREE.Mesh(boxGeo, em); e2.scale.set(0.1, 0.08, 0.05); e2.position.set(0.13, 2.14, 0.28); rig.add(e2);
  const armL = new THREE.Group(); armL.position.set(-0.6, 1.8, 0); rig.add(armL);
  const armR = new THREE.Group(); armR.position.set(0.6, 1.8, 0); rig.add(armR);
  P(armL, 0.26, 0.95, 0.26, v.skin, 0, -0.47, 0); P(armR, 0.26, 0.95, 0.26, v.skin, 0, -0.47, 0);

  const blob = new THREE.Mesh(blobGeo, new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35, depthWrite: false }));
  blob.rotation.x = -Math.PI / 2; blob.position.y = 0.06; blob.scale.setScalar(v.s[0] * 1.2); holder.add(blob);

  let barBg = null, barFg = null;
  if (v.bar) {
    const w = v.s[0] * 1.3;
    barBg = new THREE.Mesh(boxGeo, barBgMat); barBg.scale.set(w + 0.1, 0.22, 0.06); barBg.position.set(0, v.bar, 0);
    barFg = new THREE.Mesh(boxGeo, barFgMat); barFg.scale.set(w, 0.16, 0.08); barFg.position.set(0, v.bar, 0.01);
    holder.add(barBg, barFg);
  }
  scene.add(holder);
  return { holder, rig, legL, legR, armL, armR, parts, blob, barFg, barW: v.s[0] * 1.3, ti, x: 0, z: 0, tx: 0, tz: 0, yaw: 0,
    flashT: 0, seed: Math.random() * 10, hp: 100, dying: -1 };
}

const zmap = new Map(), dying = [];
function setZFlash(z, on) { for (const p of z.parts) p.material = on ? flashMat : p.userData.orig; }

function syncZombies(list) {
  const seen = new Set();
  for (const [id, ti, x, zz, hp] of list) {
    seen.add(id);
    let z = zmap.get(id);
    if (!z) {
      z = createZombie(ti); z.x = z.tx = x; z.z = z.tz = zz; z.yaw = Math.PI;
      z.holder.position.set(x, 0, zz); zmap.set(id, z);
    }
    if (hp < z.hp) { z.flashT = 0.08; setZFlash(z, true); }
    z.tx = x; z.tz = zz; z.hp = hp;
    if (z.barFg) {
      const f = hp / 100;
      z.barFg.scale.x = Math.max(0.001, z.barW * f);
      z.barFg.position.x = -z.barW * (1 - f) / 2;
    }
  }
  for (const [id, z] of zmap) {
    if (!seen.has(id)) { z.dying = 0; dying.push(z); zmap.delete(id); if (z.barFg) { z.barFg.visible = false; } }
  }
}

function updateZombie(z, dt, t) {
  const px = z.x, pz = z.z, k = 1 - Math.exp(-dt * 14);
  z.x += (z.tx - z.x) * k; z.z += (z.tz - z.z) * k;
  const dx = z.x - px, dz = z.z - pz, sp = Math.hypot(dx, dz) / Math.max(dt, 0.001);
  if (sp > 0.3) z.yaw = angleLerp(z.yaw, Math.atan2(dx, dz), Math.min(1, dt * 8));
  z.holder.position.set(z.x, 0, z.z);
  z.holder.rotation.y = z.yaw;
  const fr = 3 + sp * 1.3, ph = t * fr + z.seed;
  z.legL.rotation.x = Math.sin(ph) * 0.6; z.legR.rotation.x = -Math.sin(ph) * 0.6;
  z.armL.rotation.x = -1.4 + Math.sin(ph * 0.5) * 0.12; z.armR.rotation.x = -1.4 - Math.sin(ph * 0.5) * 0.12;
  z.rig.rotation.z = Math.sin(ph * 0.5) * 0.07;
  z.rig.position.y = Math.abs(Math.sin(ph)) * 0.05;
  if (z.flashT > 0) { z.flashT -= dt; if (z.flashT <= 0) setZFlash(z, false); }
}
function updateDying(dt) {
  for (let i = dying.length - 1; i >= 0; i--) {
    const z = dying[i]; z.dying += dt;
    z.rig.rotation.x = -Math.PI / 2 * Math.min(1, z.dying * 3.2);
    z.holder.position.y = -0.7 * Math.max(0, z.dying - 0.7);
    z.blob.material.opacity = Math.max(0, 0.35 - z.dying * 0.25);
    if (z.dying > 1.6) { scene.remove(z.holder); dying.splice(i, 1); }
  }
}
function clearZombies() {
  for (const z of zmap.values()) scene.remove(z.holder);
  for (const z of dying) scene.remove(z.holder);
  zmap.clear(); dying.length = 0;
}

/* ================= O'q, almaz, zarrachalar ================= */
const bulletMeshes = new Map();
const bulletKinds = [
  { geo: new THREE.BoxGeometry(0.12, 0.12, 0.8), mat: new THREE.MeshBasicMaterial({ color: 0xffd36b }) },
  { geo: new THREE.BoxGeometry(0.3, 0.3, 1.0), mat: new THREE.MeshBasicMaterial({ color: 0xff8a3a }) },
  { geo: new THREE.IcosahedronGeometry(0.32, 0), mat: new THREE.MeshBasicMaterial({ color: 0xff6a1a, transparent: true, opacity: 0.85 }) },
  { geo: new THREE.BoxGeometry(0.08, 0.08, 2.6), mat: new THREE.MeshBasicMaterial({ color: 0x9fe8ff }) },
  { geo: new THREE.BoxGeometry(0.07, 0.07, 3.4), mat: new THREE.MeshBasicMaterial({ color: 0x44e0ff }) },
  { geo: new THREE.IcosahedronGeometry(0.42, 0), mat: new THREE.MeshBasicMaterial({ color: 0x57ff9a, transparent: true, opacity: 0.9 }) }
];
function syncBullets(list) {
  const seen = new Set();
  for (const [id, x, z, kind] of list) {
    seen.add(id);
    let b = bulletMeshes.get(id);
    if (!b) {
      const kd = bulletKinds[kind] || bulletKinds[0];
      b = { mesh: new THREE.Mesh(kd.geo, kd.mat), x, z, kind };
      scene.add(b.mesh); bulletMeshes.set(id, b);
    }
    const dx = x - b.x, dz = z - b.z;
    if (Math.abs(dx) + Math.abs(dz) > 0.001) b.mesh.rotation.y = Math.atan2(dx, dz);
    b.x = x; b.z = z;
    b.mesh.position.set(x, BULLET_Y, z);
    if (kind === 2) { const s = 0.6 + Math.random() * 0.9; b.mesh.scale.setScalar(s); }
    if (kind === 1 && Math.random() < 0.7) burst(x, BULLET_Y, z, [0x777777, 0xaaaaaa], 1, 0.4);
  }
  for (const [id, b] of bulletMeshes) if (!seen.has(id)) { scene.remove(b.mesh); bulletMeshes.delete(id); }
}

const gemMeshes = new Map();
const gemGeo = new THREE.OctahedronGeometry(0.38, 0);
const gemMat = new THREE.MeshLambertMaterial({ color: 0x57e6ff, emissive: 0x1a8fb0 });
function syncGems(list) {
  const seen = new Set();
  for (const [id, x, z, v] of list) {
    seen.add(id);
    if (!gemMeshes.has(id)) {
      const m = new THREE.Mesh(gemGeo, gemMat);
      m.scale.setScalar(v >= 40 ? 2.4 : v >= 5 ? 1.6 : 1);
      m.position.set(x, 0.9, z); m.userData.seed = Math.random() * 6; scene.add(m); gemMeshes.set(id, m);
    }
  }
  for (const [id, m] of gemMeshes) if (!seen.has(id)) { scene.remove(m); gemMeshes.delete(id); }
}
function clearAllFx() {
  syncBullets([]); syncGems([]); clearZombies(); clearBlood();
}

const particles = [];
const pGeo = new THREE.BoxGeometry(0.16, 0.16, 0.16);
function burst(x, y, z, colors, n, life = 0.7) {
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(pGeo, new THREE.MeshBasicMaterial({ color: colors[i % colors.length], transparent: true }));
    m.position.set(x, y, z); scene.add(m);
    particles.push({ m, vx: (Math.random() - 0.5) * 7, vy: Math.random() * 6 + 2, vz: (Math.random() - 0.5) * 7, life, max: life });
  }
}
function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life -= dt; p.vy -= 18 * dt;
    p.m.position.x += p.vx * dt; p.m.position.y = Math.max(0.05, p.m.position.y + p.vy * dt); p.m.position.z += p.vz * dt;
    p.m.material.opacity = Math.max(0, p.life / p.max);
    if (p.life <= 0) { scene.remove(p.m); p.m.material.dispose(); particles.splice(i, 1); }
  }
}
/* ---- zombi o'lganda yerda qon dog'i ---- */
const bloods = [];
const bloodGeo = new THREE.CircleGeometry(1, 10);
function bloodSplat(x, z, type) {
  const R = [0.9, 0.7, 1.5, 3.0][type] || 0.9;
  const mat = new THREE.MeshBasicMaterial({ color: 0x6d0e14, transparent: true, opacity: 0.88, depthWrite: false });
  const g = new THREE.Group();
  g.position.set(x, 0.05 + Math.random() * 0.02, z); g.rotation.x = -Math.PI / 2;
  const n = 4 + Math.floor(Math.random() * 3) + (type >= 2 ? 4 : 0);
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(bloodGeo, mat), a = Math.random() * 6.283, d = i ? Math.random() * R * 1.0 : 0;
    const s = (i ? 0.18 + Math.random() * 0.32 : 1) * R;
    m.position.set(Math.cos(a) * d, Math.sin(a) * d, 0);
    m.scale.set(s * (0.8 + Math.random() * 0.5), s * (0.8 + Math.random() * 0.5), 1);
    g.add(m);
  }
  g.scale.setScalar(0.2); scene.add(g);
  bloods.push({ g, mat, age: 0, life: 30 });
  while (bloods.length > 90) { const b = bloods.shift(); scene.remove(b.g); b.mat.dispose(); }
}
function updateBlood(dt) {
  for (let i = bloods.length - 1; i >= 0; i--) {
    const b = bloods[i]; b.age += dt;
    const k = Math.min(1, b.age / 0.3);
    b.g.scale.setScalar(0.2 + 0.8 * (1 - (1 - k) * (1 - k)));
    if (b.age > b.life - 5) b.mat.opacity = 0.88 * Math.max(0, (b.life - b.age) / 5);
    if (b.age >= b.life) { scene.remove(b.g); b.mat.dispose(); bloods.splice(i, 1); }
  }
}
function clearBlood() { for (const b of bloods) { scene.remove(b.g); b.mat.dispose(); } bloods.length = 0; }
const booms = [];
function explosion(x, z, r) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), new THREE.MeshBasicMaterial({ color: 0xff9a3a, transparent: true, opacity: 0.8 }));
  m.position.set(x, 1.2, z); scene.add(m); booms.push({ m, r, t: 0 });
  burst(x, 1.2, z, [0xff9a3a, 0xffd36b, 0x555555], 22, 0.9);
  shake = Math.max(shake, 0.9);
}
function updateBooms(dt) {
  for (let i = booms.length - 1; i >= 0; i--) {
    const b = booms[i]; b.t += dt;
    const k = Math.min(1, b.t / 0.35);
    b.m.scale.setScalar(b.r * (0.3 + k * 0.9)); b.m.material.opacity = 0.8 * (1 - k);
    if (k >= 1) { scene.remove(b.m); b.m.material.dispose(); b.m.geometry.dispose(); booms.splice(i, 1); }
  }
}

/* ================= Ovoz ================= */
let actx = null, lastSfx = 0;
function initAudio() {
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
  } catch (e) {}
}
function noise(dur, vol, lp) {
  if (!actx) return;
  const n = Math.floor(actx.sampleRate * dur), buf = actx.createBuffer(1, n, actx.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
  const s = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain();
  f.type = 'lowpass'; f.frequency.value = lp; g.gain.value = vol;
  s.buffer = buf; s.connect(f); f.connect(g); g.connect(actx.destination); s.start();
}
function tone(f0, f1, dur, vol, type) {
  if (!actx) return;
  const o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime;
  o.type = type || 'sine';
  o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
}
const SFX = { pistol: [.22, 1800, .12], revolver: [.32, 1200, .16], smg: [.12, 2500, .07], shotgun: [.4, 900, .2], rifle: [.2, 2200, .1],
  sniper: [.35, 3500, .25], flame: [.07, 600, .06], rocket: [.35, 500, .3], minigun: [.1, 2800, .05],
  crossbow: [.16, 2000, .1], grenade: [.4, 450, .3], laser: [.1, 4000, .06], plasma: [.2, 1500, .12], railgun: [.45, 3000, .3] };
function sfxShot(w) {
  const now = performance.now(); if (now - lastSfx < 45) return; lastSfx = now;
  const c = SFX[w] || SFX.pistol; noise(c[2], c[0], c[1]);
}
const sfxHit = () => tone(160, 45, 0.2, 0.35);
const sfxZ = () => { const n = performance.now(); if (n - lastSfx < 25) return; tone(90 + Math.random() * 40, 40, 0.12, 0.12, 'sawtooth'); };
const sfxPick = () => tone(900, 1500, 0.12, 0.18, 'triangle');
const sfxBoom = () => { noise(0.5, 0.45, 400); tone(90, 30, 0.4, 0.4); };

/* ================= Render halqasi ================= */
let myAim = null;
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  const t = now / 1000;

  const ak = Math.min(1, dt * 1.6);
  if (Math.abs(arena.tx - arena.ax) > 0.005 || Math.abs(arena.tz - arena.az) > 0.005) {
    arena.ax += (arena.tx - arena.ax) * ak; arena.az += (arena.tz - arena.az) * ak;
    layoutArena(arena.ax, arena.az);
  }
  for (const s of SIDES) updateFighter(fighters[s], dt, t);
  for (const z of zmap.values()) updateZombie(z, dt, t);
  updateDying(dt); updateParticles(dt); updateBooms(dt); updateFly(dt); updateBlood(dt);
  for (const m of gemMeshes.values()) { m.rotation.y = t * 2 + m.userData.seed; m.position.y = 0.9 + Math.sin(t * 3 + m.userData.seed) * 0.15; }

  // kamera: jamoa markazini kuzatadi, level oshgani sari biroz uzoqlashadi
  const halfView = 23.5 + Math.min(curLevel, MAX_LEVEL) * 0.15;
  const wantDist = Math.max(30, halfView / tanHalfH);
  camDist += (wantDist - camDist) * Math.min(1, dt * 2);
  let cx = 0, cz = 1, cn = 0;
  for (const s of SIDES) { const f = fighters[s]; if (f.present && f.alive) { cx += f.x; cz += f.z; cn++; } }
  if (cn && roomCode) { cx /= cn; cz = cz / cn + 1; } else { cx = 0; cz = 1; }
  const limX = Math.max(0, arena.ax + 4 - halfView), limZ = Math.max(0, arena.az + 4 - halfView * 0.55);
  const kk = Math.min(1, dt * 3);
  camTarget.x += (Math.max(-limX, Math.min(limX, cx)) - camTarget.x) * kk;
  camTarget.z += (Math.max(-limZ, Math.min(limZ, cz)) - camTarget.z) * kk;
  moon.position.set(camTarget.x - 14, 28, camTarget.z + 14); moon.target.position.set(camTarget.x, 0, camTarget.z);
  scene.fog.near = camDist + 40; scene.fog.far = camDist + 170;
  shake = Math.max(0, shake - dt * 2.5);
  camera.position.set(
    camTarget.x + camDir.x * camDist + Math.sin(t * 0.12) * 1.2 + (Math.random() - 0.5) * shake,
    camTarget.y + camDir.y * camDist + (Math.random() - 0.5) * shake,
    camTarget.z + camDir.z * camDist
  );
  camera.lookAt(camTarget);
  renderer.render(scene, camera);

  if (shopOpen && shopR) {
    if (shopR.pop > 0) { shopR.pop = Math.max(0, shopR.pop - dt * 3); applyShopScale(); }
    if (shopR.model) shopR.model.rotation.y = t * 0.9;
    shopR.renderer.render(shopR.scene, shopR.cam);
  }
}
resize();
requestAnimationFrame(frame);

/* ================= HUD va panel ================= */
function setBanner(big, sub, pop, ms) {
  const el = $('banner'), token = ++bannerToken;
  if (!big && !sub) { el.hidden = true; return; }
  el.hidden = false;
  const b = $('bannerBig'); b.textContent = big || '';
  b.classList.remove('pop'); if (pop) { void b.offsetWidth; b.classList.add('pop'); }
  $('bannerSub').textContent = sub || '';
  if (ms) setTimeout(() => { if (token === bannerToken) el.hidden = true; }, ms);
}
function updateGemUi(pulse) {
  const n = profile.diamonds | 0;
  $('gemTotal').textContent = n; $('lobbyGems').textContent = n; $('shopGems').textContent = n;
  if (pulse) { const g = $('gemBox'); g.classList.remove('pulse'); void g.offsetWidth; g.classList.add('pulse'); }
}
function renderHud(pl) {
  const bySide = {};
  (lastRoom ? lastRoom.players : []).forEach(p => bySide[p.side] = p);
  for (const s of SIDES) {
    const p = bySide[s], f = fighters[s], cap = s[0].toUpperCase() + s.slice(1);
    $('name' + cap).textContent = p ? p.name + (s === mySide ? ' (siz)' : '') : '';
    $('hp' + cap).style.width = (p ? Math.max(0, f.hp) : 0) + '%';
    const row = document.querySelector('.prow.' + s);
    row.hidden = !p; row.classList.toggle('dead', !!p && !f.alive);
  }
  if (pl) {
    const me = pl.find(x => x.s === mySide);
    $('gemSession').textContent = me && me.g ? '+' + me.g : '';
  }
}

const SIDE_LABEL = { left: 'chap darvoza', right: "o'ng darvoza", back: 'orqa darvoza' };
function renderLevelSelect() {
  const players = lastRoom ? lastRoom.players : [];
  const minBest = players.length ? Math.min(...players.map(p => p.best || 0)) : 0;
  const levels = [1];
  for (let k = 5; k <= Math.min(minBest, MAX_LEVEL - 5); k += 5) levels.push(k + 1);
  const key = levels.join(',');
  const sel = $('levelSel');
  if (key !== levelKey) {
    levelKey = key; sel.textContent = '';
    levels.forEach(l => { const o = document.createElement('option'); o.value = l; o.textContent = l + '-level' + (l === 1 ? ' (boshidan)' : ' (davom ettirish)'); sel.appendChild(o); });
    sel.value = String(levels[levels.length - 1]);
  }
  $('levelRow').hidden = levels.length < 2;
  sel.disabled = !isHost;
}
function renderPanel() {
  updateTouch();
  const show = !!roomCode && (roomState === 'lobby' || roomState === 'over') && !shopOpen;
  $('roomPanel').hidden = !show;
  if (!show || !lastRoom) return;
  $('panelCode').textContent = roomCode;
  const over = roomState === 'over' && lastResult;
  $('panelTitle').textContent = over ? (lastResult.win ? "G'alaba!" : "O'yin tugadi") : 'Xona tayyor';
  if (over) {
    const mine = lastResult.players.find(p => p.side === mySide);
    const head = lastResult.win ? `Siz hamma ${MAX_LEVEL} levelni o'tdingiz!` : `${lastResult.level}-levelda yengildingiz.`;
    $('panelSub').textContent = `${head} ${lastResult.kills} ta zombi yo'q qilindi. Siz ${mine ? mine.gems : 0} ta almaz yig'dingiz.`;
  } else {
    const n = lastRoom.players.length;
    $('panelSub').textContent = n < 3 ? `Jamoada ${n} kishi. Do'stlaringizga kodni yuboring (3 kishigacha) yoki hoziroq boshlang.` : 'Uch jangchi ham tayyor.';
  }
  const ul = $('roster'); ul.textContent = '';
  for (const s of SIDES) {
    const p = lastRoom.players.find(x => x.side === s);
    const li = document.createElement('li'); li.className = p ? s : 'empty';
    const a = document.createElement('span'), b = document.createElement('small');
    if (p) { a.textContent = p.name + (p.host ? ' (host)' : ''); b.textContent = byId[p.weapon] ? byId[p.weapon].name : ''; }
    else { a.textContent = "Bo'sh joy"; b.textContent = SIDE_LABEL[s]; }
    li.append(a, b); ul.appendChild(li);
  }
  renderLevelSelect();
  const sb = $('startBtn');
  sb.disabled = !isHost;
  sb.textContent = isHost ? (roomState === 'over' ? "Yana o'ynash" : "O'yinni boshlash") : 'Host boshlashini kuting...';
}

/* ================= Tarmoq ================= */
socket.on('connect', () => {
  socket.emit('hello', nameInput.value.trim(), res => {
    profile = res.profile; weapons = res.weapons; byId = {};
    if (res.upgrade) upCfg = res.upgrade;
    weapons.forEach(w => byId[w.id] = w);
    setWeapon(fighters[mySide || 'left'], profile.equipped, lvlOf(profile.equipped));
    updateGemUi(false);
    if (shopOpen) renderShop();
  });
});
socket.on('connect_error', () => lobbyError("Serverga ulanib bo'lmadi."));
socket.on('disconnect', () => setBanner('Aloqa uzildi', 'Sahifani yangilang va qayta kiring.'));
socket.on('profile', p => { profile.diamonds = p.diamonds; updateGemUi(true); if (shopOpen) renderShop(); });

socket.on('room', info => {
  lastRoom = info; roomState = info.state;
  if ((info.state === 'playing' || info.state === 'countdown') && (phase === 'lobby' || phase === 'over')) phase = info.state;   // o'yin o'rtasida qo'shilgan o'yinchi
  const me = info.players.find(p => p.side === mySide);
  isHost = !!(me && me.host);
  for (const s of SIDES) {
    const p = info.players.find(x => x.side === s), f = fighters[s], was = f.present;
    f.present = !!p;
    if (p && !was) f.snap = true;
    if (p) { f.name = p.name; if (info.state !== 'playing' && info.state !== 'countdown') setWeapon(f, p.weapon, p.weaponLevel || 0); }
    if (p && info.state === 'lobby') {
      f.alive = true; f.hp = 100; f.tx = f.x = SPAWN[s].x; f.tz = f.z = SPAWN[s].z; f.snap = false;
    }
  }
  if (info.state === 'lobby') {
    clearAllFx(); phase = 'lobby'; setBanner(); curLevel = 0;
    arena.tx = 20; arena.tz = 13;
  }
  renderHud(); renderPanel();
});

socket.on('start', d => {
  phase = 'countdown'; lastResult = null; roomState = 'countdown';
  clearAllFx();
  arena.tx = arena.ax = d.ax; arena.tz = arena.az = d.az; layoutArena(arena.ax, arena.az);
  curLevel = d.level - 1;
  for (const s of SIDES) {
    const f = fighters[s]; f.alive = true; f.hp = 100; f.fall = 0; f.flash = 0; f.snap = true;
  }
  $('waveNo').textContent = d.level; $('zLeft').textContent = '0';
  renderPanel(); renderHud();
  let n = d.countdown;
  const sideTxt = `${d.level}-level. ` + (mySide === 'left' ? 'Siz chap darvozadan kirasiz' : mySide === 'right' ? "Siz o'ng darvozadan kirasiz" : 'Siz orqa darvozadan kirasiz');
  setBanner(String(n), sideTxt, true);
  clearInterval(countdownTimer);
  countdownTimer = setInterval(() => { n--; if (n > 0) setBanner(String(n), sideTxt, true); else clearInterval(countdownTimer); }, 1000);
});
socket.on('go', () => { phase = 'playing'; roomState = 'playing'; clearInterval(countdownTimer); updateTouch(); setBanner("TAYYOR BO'LING", '', true, 900); });

socket.on('wave', d => {
  arena.tx = d.ax; arena.tz = d.az; curLevel = d.n;
  const title = d.final ? 'OXIRGI LEVEL! SUPER BOSS' : d.boss ? `BOSS! ${d.n}-level` : `${d.n}-level`;
  setBanner(title, `${d.count} ta zombi` + (d.n > 1 ? '. Xarita kattalashdi!' : ' yaqinlashmoqda'), true, 2400);
});
socket.on('waveclear', d => {
  setBanner(`${d.n}-level tozalandi!`, `Bonus +${d.bonus} almaz. Do'konga kirish: B tugmasi.`, true, 3500);
});

socket.on('state', s => {
  if (phase === 'lobby') return;
  arena.tx = s.w.ax; arena.tz = s.w.az; curLevel = s.w.n;
  $('waveNo').textContent = Math.max(1, s.w.n); $('zLeft').textContent = s.w.left;
  for (const p of s.p) {
    const f = fighters[p.s]; if (!f) continue;
    if (!f.present || f.snap) { f.present = true; f.x = p.x; f.z = p.z; f.snap = false; }
    f.tx = p.x; f.tz = p.z; f.hp = p.hp; f.alive = !!p.a; f.aim = p.aim;
    if (weapons[p.w]) setWeapon(f, weapons[p.w].id, p.wl || 0);
  }
  syncZombies(s.z); syncBullets(s.b); syncGems(s.g);
  renderHud(s.p);
});
socket.on('shot', d => { const f = fighters[d.side]; if (f) { f.kick = 1; sfxShot(d.weapon); } });
socket.on('phit', d => {
  const f = fighters[d.side]; if (!f) return;
  f.flash = 0.2; f.hp = d.hp;
  if (d.side === mySide) { shake = Math.max(shake, 0.45); sfxHit(); }
  renderHud();
});
socket.on('pdie', d => { const f = fighters[d.side]; if (!f) return; f.alive = false; burst(f.x, 1.5, f.z, [0xd94040, 0x7a1a1a], 14); renderHud(); });
socket.on('zdie', d => { bloodSplat(d.x, d.z, d.type); burst(d.x, 1.2, d.z, d.type >= 2 ? [0xa01820, 0x6fa35a, 0x7a1a1a] : [0xa01820, 0x7a1a1a, 0x6fa35a], d.type === 3 ? 30 : d.type === 2 ? 14 : 8); sfxZ(); if (d.type === 3) shake = 1; });
socket.on('boom', d => { explosion(d.x, d.z, d.r); sfxBoom(); });
const flyGems = [];
socket.on('pick', d => {
  const f = fighters[d.side]; if (!f) return;
  const m = new THREE.Mesh(gemGeo, gemMat), s0 = d.v >= 40 ? 2.4 : d.v >= 5 ? 1.6 : 1;
  m.position.set(d.x, 1, d.z); m.scale.setScalar(s0); scene.add(m);
  flyGems.push({ m, t: 0, s0, sx: d.x, sz: d.z, f });
  if (d.side === mySide) sfxPick();
});
function updateFly(dt) {
  for (let i = flyGems.length - 1; i >= 0; i--) {
    const g = flyGems[i]; g.t += dt;
    const k = Math.min(1, g.t / 0.45), e = k * k;
    g.m.position.set(g.sx + (g.f.x - g.sx) * e, 1 + 0.9 * e + Math.sin(k * Math.PI) * 1.2, g.sz + (g.f.z - g.sz) * e);
    g.m.rotation.y += dt * 12; g.m.scale.setScalar(g.s0 * (1 - 0.5 * k));
    if (k >= 1) { scene.remove(g.m); flyGems.splice(i, 1); }
  }
}
socket.on('over', d => {
  phase = 'over'; roomState = 'over'; lastResult = d; levelKey = ''; updateTouch();
  setBanner(d.win ? "G'ALABA!" : "O'yin tugadi", d.win ? `${MAX_LEVEL} level o'tildi` : `${d.level}-level`, true);
  setTimeout(() => { if (phase === 'over') { setBanner(); renderPanel(); } }, 1600);
});

/* ================= Lobbi ================= */
const nameInput = $('nameInput'), codeInput = $('codeInput');
try { nameInput.value = localStorage.getItem('kd_name') || ''; } catch (e) {}
const urlCode = new URLSearchParams(location.search).get('room');
if (urlCode) codeInput.value = urlCode.toUpperCase().slice(0, 4);
function getName() { const n = nameInput.value.trim(); try { localStorage.setItem('kd_name', n); } catch (e) {} return n; }
function lobbyError(m) { $('lobbyError').textContent = m || ''; }

function enterRoom(res) {
  if (!res || !res.ok) { lobbyError((res && res.error) || 'Xatolik yuz berdi.'); return; }
  mySide = res.side; roomCode = res.code;
  setWeapon(fighters[mySide], profile.equipped, lvlOf(profile.equipped));
  $('lobby').hidden = true; $('zhud').hidden = false; $('chatToggle').hidden = false;
  $('roomCodeTag').textContent = roomCode;
  if (window.innerWidth > 760) openChat(true);
  history.replaceState(null, '', '?room=' + roomCode);
  resize(); renderHud(); renderPanel();
}
$('createBtn').addEventListener('click', () => { initAudio(); lobbyError(''); socket.emit('create', getName(), enterRoom); });
function doJoin() {
  initAudio(); lobbyError('');
  const code = codeInput.value.trim().toUpperCase();
  if (code.length !== 4) { lobbyError('Kod 4 ta belgidan iborat.'); return; }
  socket.emit('join', code, getName(), enterRoom);
}
$('joinBtn').addEventListener('click', doJoin);
$('lobbyForm').addEventListener('submit', e => { e.preventDefault(); doJoin(); });
codeInput.addEventListener('input', () => { codeInput.value = codeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
$('copyBtn').addEventListener('click', () => {
  const link = location.origin + '/zombie.html?room=' + roomCode, b = $('roomCodeTag'), old = roomCode;
  const done = () => { b.textContent = 'Nusxalandi'; setTimeout(() => b.textContent = old, 1200); };
  if (navigator.clipboard) navigator.clipboard.writeText(link).then(done, done); else done();
});
$('startBtn').addEventListener('click', () => { initAudio(); socket.emit('start', parseInt($('levelSel').value, 10) || 1); });
$('leaveBtn').addEventListener('click', () => { socket.emit('leave'); history.replaceState(null, '', location.pathname); location.reload(); });

/* ================= Do'kon ================= */
function initShopScene() {
  const r = new THREE.WebGLRenderer({ canvas: $('shopCanvas'), antialias: true, alpha: true });
  r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); r.setClearColor(0x000000, 0);
  const sc = new THREE.Scene();
  sc.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.0));
  const d = new THREE.DirectionalLight(0xffffff, 0.9); d.position.set(2, 3, 4); sc.add(d);
  const cam = new THREE.PerspectiveCamera(35, 2, 0.1, 50); cam.position.set(0, 0.5, 4); cam.lookAt(0, 0, 0);
  shopR = { renderer: r, scene: sc, cam, model: null };
}
function resizeShop() {
  const c = $('shopCanvas'), w = c.clientWidth || 300, h = c.clientHeight || 150;
  shopR.renderer.setSize(w, h, false); shopR.cam.aspect = w / h; shopR.cam.updateProjectionMatrix();
}
function shopPreview(id) {
  if (shopR.model) shopR.scene.remove(shopR.model);
  const m = weaponModel(id), g = new THREE.Group();
  m.position.z = -(m.userData.len || 1) / 2 + 0.15; g.add(m);
  g.userData.base = Math.max(1.8, Math.min(4, 3.2 / Math.max(m.userData.len || 1, 0.8)));
  g.rotation.x = 0.25;
  shopR.model = g; shopR.scene.add(g); shopR.pop = 0;
  applyShopScale();
}
function applyShopScale() {
  if (!shopR || !shopR.model) return;
  const lvl = lvlOf(shopSel);
  shopR.model.scale.setScalar(shopR.model.userData.base * (1 + 0.08 * lvl) * (1 + 0.25 * (shopR.pop || 0)));
}
function wStats(w, lvl) {
  lvl = lvl || 0;
  const dmg = w.dmg * (1 + upCfg.dmgPer * lvl) * w.pellets * (w.splash ? 2.2 : 1) * (1 + w.pierce * 0.15);
  return { dmg, rate: 1000 / (w.cd * (1 - upCfg.cdPer * lvl)), range: w.speed * w.life };
}
function renderShop() {
  if (!weapons.length) return;
  if (!shopSel || !byId[shopSel]) shopSel = profile.equipped;
  $('shopGems').textContent = profile.diamonds | 0;
  const all = weapons.map(w => wStats(w, upCfg.max));
  const mx = { dmg: Math.max(...all.map(a => a.dmg)), rate: Math.max(...all.map(a => a.rate)), range: Math.max(...all.map(a => a.range)) };
  const list = $('shopList'); list.textContent = '';
  for (const w of weapons) {
    const owned = profile.owned.includes(w.id), eq = profile.equipped === w.id, lv = lvlOf(w.id);
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'card' + (shopSel === w.id ? ' sel' : '') + (eq ? ' equipped' : '') + (owned ? '' : ' locked');
    const n = document.createElement('b'); n.textContent = w.name;
    const t = document.createElement('span'); t.className = 'tag';
    if (owned) t.textContent = (eq ? 'Tanlangan' : 'Sizda bor') + (lv ? ' • Lv ' + lv : '');
    else { const g = document.createElement('i'); g.className = 'gem'; t.append(g, String(w.price)); }
    b.append(n, t);
    b.addEventListener('click', () => { shopSel = w.id; $('shopMsg').textContent = ''; $('shopMsg').className = ''; shopPreview(w.id); renderShop(); });
    list.appendChild(b);
  }
  const w = byId[shopSel], lvl = lvlOf(w.id), st = wStats(w, lvl), owned = profile.owned.includes(w.id), eq = profile.equipped === w.id;
  $('shopName').textContent = w.name + (w.price ? '' : ' (bepul)');
  $('shopDesc').textContent = w.desc;
  $('stDmg').style.width = (st.dmg / mx.dmg * 100) + '%';
  $('stRate').style.width = (st.rate / mx.rate * 100) + '%';
  $('stRange').style.width = (st.range / mx.range * 100) + '%';

  // KUCHAYTIRISH (do'konda birinchi blok)
  const pips = $('upPips'); pips.textContent = '';
  for (let i = 0; i < upCfg.max; i++) { const p = document.createElement('i'); if (i < lvl) p.className = 'on'; pips.appendChild(p); }
  $('upLevel').textContent = owned ? `Daraja ${lvl}/${upCfg.max}` : 'Sotib olinmagan';
  const ub = $('upBtn'), cost = (w.ucost || [])[lvl];
  if (!owned) { ub.textContent = 'Avval qurolni sotib oling'; ub.disabled = true; $('upInfo').textContent = `Har daraja: zarar +${Math.round(upCfg.dmgPer * 100)}%, otish tezligi +${Math.round(upCfg.cdPer * 100)}%, qurol qo'lda kattalashadi.`; }
  else if (lvl >= upCfg.max) { ub.textContent = 'Maksimal daraja'; ub.disabled = true; $('upInfo').textContent = 'Bu qurol to\'liq kuchaytirilgan.'; }
  else {
    ub.textContent = `Kuchaytirish: ${cost} almaz`; ub.disabled = profile.diamonds < cost;
    $('upInfo').textContent = `Keyingi daraja: zarar +${Math.round(upCfg.dmgPer * 100)}%, otish tezligi +${Math.round(upCfg.cdPer * 100)}%, qurol kattalashadi.`;
  }
  applyShopScale();

  const a = $('shopAction');
  if (eq) { a.textContent = 'Tanlangan'; a.disabled = true; }
  else if (owned) { a.textContent = 'Tanlash'; a.disabled = false; }
  else { a.textContent = `Sotib olish: ${w.price} almaz`; a.disabled = profile.diamonds < w.price; }
}
$('upBtn').addEventListener('click', () => {
  const w = byId[shopSel]; if (!w) return;
  const msg = $('shopMsg');
  socket.emit('shop:upgrade', w.id, res => {
    if (!res.ok) { msg.textContent = res.error; msg.className = 'bad'; return; }
    profile = res.profile; updateGemUi(false);
    msg.textContent = 'Qurol kuchaytirildi!'; msg.className = 'ok';
    if (shopR) shopR.pop = 1;
    if (mySide) setWeapon(fighters[mySide], profile.equipped, lvlOf(profile.equipped));
    sfxPick(); renderShop();
  });
});
$('shopAction').addEventListener('click', () => {
  const w = byId[shopSel]; if (!w) return;
  const owned = profile.owned.includes(w.id), msg = $('shopMsg');
  socket.emit(owned ? 'shop:equip' : 'shop:buy', w.id, res => {
    if (!res.ok) { msg.textContent = res.error; msg.className = 'bad'; return; }
    profile = res.profile; updateGemUi(false);
    msg.textContent = owned ? 'Qurol tanlandi.' : 'Sotib olindi va qo\'lingizda!'; msg.className = 'ok';
    if (mySide) setWeapon(fighters[mySide], profile.equipped, lvlOf(profile.equipped));
    renderShop();
  });
});
function openShop() {
  initAudio();
  if (!shopR) initShopScene();
  shopOpen = true; $('shop').hidden = false;
  releaseAll();
  shopSel = profile.equipped; $('shopMsg').textContent = ''; $('shopMsg').className = '';
  resizeShop(); shopPreview(shopSel); renderShop(); renderPanel();
}
function closeShop() { shopOpen = false; $('shop').hidden = true; renderPanel(); }
['shopBtn', 'lobbyShopBtn', 'panelShopBtn'].forEach(id => $(id).addEventListener('click', openShop));
$('shopClose').addEventListener('click', closeShop);
$('shop').addEventListener('pointerdown', e => { if (e.target === $('shop')) closeShop(); });

/* ================= Chat ================= */
const chatEl = $('chat'), logEl = $('chatLog'), chatInput = $('chatInput');
let unread = 0;
function openChat(open) {
  chatEl.hidden = !open;
  if (open) { unread = 0; $('badge').hidden = true; logEl.scrollTop = logEl.scrollHeight; }
}
$('chatToggle').addEventListener('click', () => openChat(chatEl.hidden));
socket.on('chat', m => {
  const div = document.createElement('div');
  if (m.sys) { div.className = 'msg sys'; div.textContent = m.text; }
  else {
    div.className = 'msg ' + m.side + (m.side === mySide ? ' me' : '');
    const b = document.createElement('b'); b.textContent = m.name;
    const s = document.createElement('span'); s.textContent = m.text;
    div.append(b, s);
  }
  logEl.appendChild(div);
  while (logEl.children.length > 100) logEl.removeChild(logEl.firstChild);
  logEl.scrollTop = logEl.scrollHeight;
  if (chatEl.hidden && !m.sys) { unread++; $('badge').textContent = unread; $('badge').hidden = false; }
});
$('chatForm').addEventListener('submit', e => {
  e.preventDefault();
  const t = chatInput.value.trim();
  if (t) socket.emit('chat', t);
  chatInput.value = '';
});
chatInput.addEventListener('keydown', e => { if (e.key === 'Escape') chatInput.blur(); });

/* ================= Boshqaruv va nishon ================= */
const input = { u: 0, d: 0, l: 0, r: 0, f: 0, a: 0, mx: 0, mz: 0 };
let stickAim = null;
const mouse = { x: 0, y: 0, has: false };
const raycaster = new THREE.Raycaster(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -1.2), hitPt = new THREE.Vector3();

function computeAim() {
  const me = mySide && fighters[mySide];
  if (!me) return input.a;
  if (touchMode) {                           // telefon: eng yaqin zombiga avto-nishon
    let best = null, bd = 1e9;
    for (const z of zmap.values()) { const d = Math.hypot(z.tx - me.x, z.tz - me.z); if (d < bd) { bd = d; best = z; } }
    if (best) return Math.atan2(best.tz - me.z, best.tx - me.x);
    return input.a;
  }
  if (mouse.has) {                           // kompyuter: sichqoncha bilan nishon
    raycaster.setFromCamera({ x: mouse.x / innerWidth * 2 - 1, y: -(mouse.y / innerHeight) * 2 + 1 }, camera);
    if (raycaster.ray.intersectPlane(plane, hitPt)) return Math.atan2(hitPt.z - me.z, hitPt.x - me.x);
  }
  return input.a;
}
let lastSent = '';
function sendInput() {
  if (!roomCode) return;
  const a = computeAim(); input.a = Math.round(a * 20) / 20; myAim = input.a;
  const k = JSON.stringify(input);
  if (k !== lastSent) { lastSent = k; socket.emit('input', input); }
}
setInterval(sendInput, 50);
function releaseAll() { input.u = input.d = input.l = input.r = input.f = 0; input.mx = input.mz = 0; stickAim = null; sendInput(); }

const keyMap = { KeyW: 'u', ArrowUp: 'u', KeyS: 'd', ArrowDown: 'd', KeyA: 'l', ArrowLeft: 'l', KeyD: 'r', ArrowRight: 'r' };
const typing = () => { const a = document.activeElement; return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA'); };
window.addEventListener('keydown', e => {
  if (e.code === 'Escape' && shopOpen) { closeShop(); return; }
  if (typing() || !roomCode || shopOpen) return;
  if (keyMap[e.code]) { input[keyMap[e.code]] = 1; e.preventDefault(); }
  else if (e.code === 'Space') { input.f = 1; e.preventDefault(); }
  else if (e.code === 'KeyB') { openShop(); e.preventDefault(); }
  else if (e.code === 'Enter') { openChat(true); chatInput.focus(); e.preventDefault(); }
});
window.addEventListener('keyup', e => {
  if (keyMap[e.code]) input[keyMap[e.code]] = 0;
  else if (e.code === 'Space') input.f = 0;
});
window.addEventListener('blur', releaseAll);
window.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') { mouse.x = e.clientX; mouse.y = e.clientY; mouse.has = true; } });
canvas.addEventListener('pointerdown', e => { if (e.pointerType === 'mouse' && e.button === 0 && roomCode) { input.f = 1; initAudio(); } });
['pointerup', 'pointercancel'].forEach(ev => window.addEventListener(ev, e => { if (e.pointerType === 'mouse') input.f = 0; }));
canvas.addEventListener('contextmenu', e => e.preventDefault());


function makeStick(el, onMove, onEnd) {
  const knob = el.querySelector('.knob');
  let pid = null, cx = 0, cy = 0;
  const R = () => el.getBoundingClientRect().width * 0.34;
  const set = (dx, dy) => {
    const r = R(), m = Math.hypot(dx, dy), k = m > r ? r / m : 1;
    dx *= k; dy *= k;
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    onMove(dx / r, dy / r);
  };
  el.addEventListener('pointerdown', e => {
    if (pid !== null) return;
    pid = e.pointerId; try { el.setPointerCapture(pid); } catch (err) {}
    const b = el.getBoundingClientRect(); cx = b.left + b.width / 2; cy = b.top + b.height / 2;
    set(e.clientX - cx, e.clientY - cy); e.preventDefault();
  });
  el.addEventListener('pointermove', e => { if (e.pointerId === pid) { set(e.clientX - cx, e.clientY - cy); e.preventDefault(); } });
  const end = e => { if (e.pointerId !== pid) return; pid = null; knob.style.transform = 'translate(0,0)'; onEnd(); };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  return { reset() { pid = null; knob.style.transform = 'translate(0,0)'; } };
}

const showTouch = touchMode || 'ontouchstart' in window;
const moveStick = makeStick($('moveStick'), (x, y) => {
  const m = Math.hypot(x, y);
  if (m < 0.12) { input.mx = input.mz = 0; return; }
  const k = (m - 0.12) / 0.88 / m;                       // o'lik zona
  input.mx = Math.round(x * k * 20) / 20; input.mz = Math.round(y * k * 20) / 20;
}, () => { input.mx = input.mz = 0; });
const fireBtn = $('fireBtn');
fireBtn.addEventListener('pointerdown', e => { e.preventDefault(); input.f = 1; fireBtn.classList.add('on'); initAudio(); });
['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => fireBtn.addEventListener(ev, () => { input.f = 0; fireBtn.classList.remove('on'); }));
function updateTouch() {
  const on = showTouch && !!roomCode && (phase === 'countdown' || phase === 'playing') && !shopOpen;
  $('touch').hidden = !on;
  if (!on) { input.mx = input.mz = 0; if (showTouch) { input.f = 0; stickAim = null; moveStick.reset(); fireBtn.classList.remove('on'); } }
}
})();
