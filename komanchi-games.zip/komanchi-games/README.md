# Komanchi Games

Onlayn 3D o'yinlar to'plami (hammasi brauzerda, xona kodi bilan ulanadi):

1. **Duel** (`/`) - 2 o'yinchi bir-biriga o'q otadi (biri chapdan, biri o'ngdan kiradi).
2. **Zombi Hujum** (`/zombie.html`) - 1, 2 yoki 3 kishilik jamoa zombilarga qarshi kurashadi.

## Ishga tushirish
```bash
npm install
npm start
```
Brauzerda: http://localhost:3000 (Node.js 16+ kerak). Boshqa port: `PORT=8080 npm start`.

> Netlify / GitHub Pages kabi **statik** hostinglarda ishlamaydi - bu Node.js serveri.
> Render.com, Railway.app yoki Replit.com ga joylashtiring: Build `npm install`, Start `npm start`.

## Zombi Hujum
- **Jamoa:** 1-o'yinchi xona yaratadi (kod oladi, **chap** darvozadan kiradi). 2-chisi **o'ng**, 3-chisi **orqa** darvozadan kiradi. Yakka ham o'ynash mumkin. Host "O'yinni boshlash" ni bosadi.
- **60 level:** har levelda xarita kattalashadi, zombilar ko'proq, kuchliroq va tezroq bo'ladi. Har 5-levelda BOSS, 60-levelda Super Boss. Hammasini o'tsangiz g'alaba.
- **Yiqilish:** yiqilgan o'rtoq keyingi levelda darvozadan qaytib kiradi. Hamma yiqilsa o'yin tugaydi.
- **Checkpoint:** jamoadagi hamma 5, 10, 15... levelni tugatgan bo'lsa, keyingi safar o'sha joydan davom ettirish mumkin.
- **Almaz:** zombilardan almaz tushadi (yuruvchi o'yinchi o'zi yig'adi). Levelni tugatganda va o'yin oxirida bonus beriladi. Almaz profilda saqlanadi.
- **Do'kon (B tugmasi yoki "Do'kon"):** 14 ta qurol - Pistolet (bepul), Revolver, SMG, Arbalet, Ov miltig'i, Miltiq, Snayper, Olov sochgich, Raketa otar, Minigan, Granata otar, Lazer, Plazma, Reylgan. Har birining narxi har xil. Sotib olingan qurol doim sizniki. Do'konning eng tepasida **Kuchaytirish** bloki: har qurolni 5 darajagacha oshirish mumkin (zarar +25%, tezlik oshadi, qurol qo'lda kattalashadi).
- **Profil:** brauzerdagi maxfiy ID orqali taniladi (parol kerak emas). Brauzer ma'lumotini o'chirsangiz, profil ham yo'qoladi.

### Boshqaruv
- Kompyuter: **WASD/strelkalar** yurish, **sichqoncha** bilan nishon, **chap tugma yoki Space** otish, **B** do'kon, **Enter** chat.
- Telefon: chapda yurish joystigi, o'ngda **OT** tugmasi; nishon eng yaqin zombiga avtomatik (telefonni yotiq tuting).

## Fayllar
- `server.js` - Express + Socket.IO, Duel rejimi.
- `zombie-server.js` - Zombi rejimi: xonalar, levellar, zombilar, o'qlar, almaz, do'kon (hamma hisob-kitob serverda).
- `weapons.js` - qurollar katalogi (narx va xususiyatlar shu yerda; o'zgartirish oson).
- `store.js` - profil saqlash (`data/players.json`). Doimiy disk uchun `DATA_DIR` muhit o'zgaruvchisini bering.
- `public/` - brauzer qismi: `index.html`+`game.js` (Duel), `zombie.html`+`zombie.js`+`zombie.css` (Zombi), `style.css`.

## Sozlash
- Level/xarita/qiyinlik: `zombie-server.js` boshidagi `CFG`, `ZT` va `startWave`, `spawnZ` funksiyalari.
- Qurol narxi va kuchi: `weapons.js`.
